import TransferScreen from "@/src/modules/financial/presentation/view/screens/transfer-screen";

const TransferPage = () => {
    return <TransferScreen />;
};

export default TransferPage; 