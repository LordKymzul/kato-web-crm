import FinancialScreen from "@/src/modules/financial/presentation/view/screens/financial-screen";

const TransactionsPage = () => {
    return <FinancialScreen />;
};

export default TransactionsPage; 