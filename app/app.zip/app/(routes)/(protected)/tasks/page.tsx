import TasksScreen from "@/src/modules/tasks/presentation/view/screens/tasks-screen";

const TasksPage = () => {
    return <TasksScreen />;
};

export default TasksPage;