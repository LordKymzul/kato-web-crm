import CLClientScreen from "@/src/modules/client_leads/presentation/view/screens/cl-client-screen"
import ClientScreen from "@/src/modules/client_leads/presentation/view/screens/cl-client-screen"

const ClientLeadsClientsPage = () => {
    return (
        <CLClientScreen />
    )
}

export default ClientLeadsClientsPage