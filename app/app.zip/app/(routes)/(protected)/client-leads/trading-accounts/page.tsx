import CLTradingAccountScreen from "@/src/modules/client_leads/presentation/view/screens/cl-trading-account-screen"

const ClientLeadsTradingAccountsPage = () => {
    return (
        <CLTradingAccountScreen />
    )
}

export default ClientLeadsTradingAccountsPage