import LeadScreen from "@/src/modules/client_leads/presentation/view/screens/cl-lead-screen"

const ClientLeadsLeadsPage = () => {
    return (
        <LeadScreen />
    )
}

export default ClientLeadsLeadsPage