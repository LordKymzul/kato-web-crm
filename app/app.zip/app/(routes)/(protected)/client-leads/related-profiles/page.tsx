import CLRelatedProfilesScreen from "@/src/modules/client_leads/presentation/view/screens/cl-related-profiles-screen"

const ClientLeadsRelatedProfilesPage = () => {
    return (
        <CLRelatedProfilesScreen />
    )
}

export default ClientLeadsRelatedProfilesPage