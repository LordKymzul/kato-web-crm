import CLDocumentScreen from "@/src/modules/client_leads/presentation/view/screens/cl-document-screen"

const ClientLeadsDocumentsPage = () => {
    return (
        <CLDocumentScreen />
    )
}

export default ClientLeadsDocumentsPage