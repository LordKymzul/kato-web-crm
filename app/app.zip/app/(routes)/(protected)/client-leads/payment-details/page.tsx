import CLPaymentDetailsScreen from "@/src/modules/client_leads/presentation/view/screens/cl-payment-details-screen"

const ClientLeadsPaymentDetailsPage = () => {
    return (
        <CLPaymentDetailsScreen />
    )
}

export default ClientLeadsPaymentDetailsPage