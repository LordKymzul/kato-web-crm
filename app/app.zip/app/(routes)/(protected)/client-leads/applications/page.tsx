import CLApplicationScreen from "@/src/modules/client_leads/presentation/view/screens/cl-application-screen"
import ApplicationScreen from "@/src/modules/client_leads/presentation/view/screens/cl-application-screen"

const ClientLeadsApplicationsPage = () => {
    return (
        <CLApplicationScreen />
    )
}

export default ClientLeadsApplicationsPage