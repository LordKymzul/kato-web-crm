import CLMessagesScreen from "@/src/modules/client_leads/presentation/view/screens/cl-message-screen"

const ClientLeadsMessagesPage = () => {
    return (
        <CLMessagesScreen />
    )
}

export default ClientLeadsMessagesPage