import CLExpiredDocumentScreen from "@/src/modules/client_leads/presentation/view/screens/cl-expired-document-screen"

const ClientExpiredDocumentsPage = () => {
    return (
        <CLExpiredDocumentScreen />
    )
}

export default ClientExpiredDocumentsPage