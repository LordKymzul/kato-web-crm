import ManagerStatsScreen from '@/src/modules/dashboard/manager-stats/screens/manager-stats-screen';

export default function ManagerStatsPage() {
    return <ManagerStatsScreen />;
}
