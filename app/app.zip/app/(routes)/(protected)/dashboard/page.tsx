import OverviewScreen from "@/src/modules/dashboard/overview/presentation/view/screens/overview-screen";

const DashboardPage = () => {
    return (
        <OverviewScreen />
    )
};

export default DashboardPage;