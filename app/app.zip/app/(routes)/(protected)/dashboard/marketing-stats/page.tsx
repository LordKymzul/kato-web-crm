import MarketingStatsScreen from '@/src/modules/dashboard/marketing-stats/screens/marketing-stats-screen';

export default function MarketingStatsPage() {
    return <MarketingStatsScreen />;
}
