import IBStatsScreen from '@/src/modules/dashboard/ib-stats/screens/ib-stats-screen';

export default function IBStatsPage() {
    return <IBStatsScreen />;
}
