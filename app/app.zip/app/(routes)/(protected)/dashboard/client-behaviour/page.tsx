import ClientBehaviorScreen from '@/src/modules/dashboard/client-behaviour/screens/client-behavior-screens';

export default function ClientBehaviourPage() {
    return <ClientBehaviorScreen />;
}