import FinancialStatsScreen from "@/src/modules/dashboard/financial_stats/presentation/view/screens/financial-stats-screen";

const FinancialPage = () => {
    return <FinancialStatsScreen />;
};

export default FinancialPage;