import CampaignsScreen from "@/src/modules/marketing/presentation/view/screens/campaigns-screen";

const CampaignsPage = () => {
    return <CampaignsScreen />;
};

export default CampaignsPage; 