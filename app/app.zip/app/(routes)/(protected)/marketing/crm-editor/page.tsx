import CrmEditorScreen from "@/src/modules/marketing/presentation/view/screens/crm-editor-screen";

const CrmEditorPage = () => {
    return <CrmEditorScreen />;
};

export default CrmEditorPage; 