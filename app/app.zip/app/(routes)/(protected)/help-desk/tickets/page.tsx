import TicketsScreen from "@/src/modules/help-desk/presentation/view/screens/tickets-screen";

const TicketsPage = () => {
    return <TicketsScreen />;
};

export default TicketsPage; 