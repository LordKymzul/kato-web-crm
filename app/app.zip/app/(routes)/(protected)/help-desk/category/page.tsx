import CategoryScreen from "@/src/modules/help-desk/presentation/view/screens/category-screen";

const CategoryPage = () => {
    return <CategoryScreen />;
};

export default CategoryPage; 